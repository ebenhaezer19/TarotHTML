function showDropdown() {
  var dropdown = document.getElementById("myDropdown");
  var dropbtn = document.getElementsByClassName("dropbtn")[0];
  dropdown.style.display = "block";
  dropdown.classList.remove("hide"); // Hapus kelas 'hide'
  
  
}

function hideDropdown() {
  var dropdown = document.getElementById("myDropdown");
  var dropbtn = document.getElementsByClassName("dropbtn")[0];
  dropdown.classList.add("hide"); // Tambahkan kelas 'hide'
}


function cancelHide() {
    var dropdown = document.getElementById("myDropdown");
    dropdown.classList.remove("hide");
  }
  